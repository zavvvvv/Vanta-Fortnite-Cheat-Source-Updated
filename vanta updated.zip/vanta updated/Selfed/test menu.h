#include "imgui/imgui.h"

inline bool customcolor = false;
inline float accentcolor[4] = { 1.f, 1.f, 1.f, 1.0f };

inline ImColor AccentCol = ImVec4(accentcolor[0], accentcolor[1], accentcolor[2], 1.0f);